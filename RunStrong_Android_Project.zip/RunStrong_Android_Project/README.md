# RunStrong Android Coach

This is a minimal Android Studio project that wraps the RunStrong beginner running-coach interface in an Android WebView.

## Build APK in GitHub (phone-friendly)
1. Create an empty GitHub repository named `RunStrong-Personal-Coach`.
2. Extract this ZIP on your phone.
3. Upload the *contents* of this folder to the repository root (including the hidden `.github` folder). Do not upload the ZIP itself.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab. Run **Build RunStrong APK** if needed, or wait for the push-triggered workflow.
6. Open the successful workflow run, scroll to **Artifacts**, and download `RunStrong-debug-apk`.
7. Extract the downloaded artifact and tap `app-debug.apk` to install. Android may ask you to allow installs from your browser/file manager.

## Notes
- This is a debug APK build, not a Play Store release.
- Workout logs and checklist are stored locally on the device in WebView storage; they do not sync to a cloud account.
- Exercise buttons open YouTube search results rather than endorsing a specific video.
- Progress gradually; stop for chest pain, faintness, severe/unusual breathlessness, or sharp/worsening pain.
